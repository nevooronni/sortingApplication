
Closure Compiler Externs for Web Animations
-------------------------------------------

This folder contains externs for using the Web Animations API with the Closure
Compiler. These externs aren't strictly part of the polyfill, as they can be
used for either the native or polyfilled versions.

web-animations-next requires that you also include web-animations.

